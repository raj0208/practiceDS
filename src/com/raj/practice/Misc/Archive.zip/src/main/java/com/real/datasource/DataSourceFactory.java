package com.real.datasource;

/**
 * DataSourceFactory class
 */
public class DataSourceFactory {


    /**
     * Get DataSource based on the datasource type passed as an argument
     *
     * @param dataSourceType DataSourceType of the required DataSource
     * @return DataSource corresponding to the datasource type
     */
    public static DataSource getDataSource(DataSourceType dataSourceType) {
        DataSource datasource;

        switch (dataSourceType) {
            case MEMORY:
                datasource = new MemoryDataSource();
                break;
            case PERSISTANT:
            default:
                throw new IllegalArgumentException("No datasource available for " + dataSourceType);
        }

        return datasource;
    }
}

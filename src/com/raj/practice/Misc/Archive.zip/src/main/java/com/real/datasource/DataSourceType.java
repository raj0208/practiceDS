package com.real.datasource;

public enum DataSourceType {
    MEMORY,
    PERSISTANT
}

package com.real.providers;

public class AmazonInstantFeedProvider implements FeedProvider{
}

package com.real.matcher;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;

import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
    public static void main(String[] args) throws IOException {
        List<String> list = Arrays.asList("c1, \"c2\", c3", "a,a,a", "b,b,b");
        CSVParser parser = new CSVParserBuilder().withSeparator(',').withQuoteChar('"').build();


    }



}

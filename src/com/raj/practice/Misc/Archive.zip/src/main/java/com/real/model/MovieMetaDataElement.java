package com.real.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@EqualsAndHashCode()
@ToString
public class MovieMetaDataElement {
    private String id;
    private String name;
    private String role;
}

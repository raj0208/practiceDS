package com.real.providers;

public class XboxFeedProvider implements FeedProvider{
}

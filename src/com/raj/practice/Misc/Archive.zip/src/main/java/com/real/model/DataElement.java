package com.real.model;

import lombok.Getter;
import lombok.ToString;

/**
 * DataElement class for movie data
 */
@Getter
@ToString
public abstract class DataElement {
    protected String id;
    protected String title;

    /**
     * Returns unique identifier to be used to identify the data element
     * Derived class must implement this method
     * @return unique identifier of the data element
     */
    public abstract String getIdentifier();
}

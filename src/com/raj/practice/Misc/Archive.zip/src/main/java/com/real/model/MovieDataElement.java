package com.real.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * MovieDataElement class for internal movie data
 */
@AllArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = false)
@ToString
public class MovieDataElement extends DataElement {
    private String year;
    @Setter
    private String director;
    @Setter
    private String cast;

    /**
     * Returns unique identifier to be used to identify the data element
     *
     * @return unique identifier of the data element
     */
    @Override
    public String getIdentifier() {
        // currently movie title is used as a unique identifier.
        // if required, it can be extended to form a composite key using multiple attributes.
        return this.title.toUpperCase();
    }
}

package com.real.datasource;

import com.real.matcher.Matcher;
import com.real.model.MovieDataElement;
import com.real.model.MovieMetaDataElement;
import com.real.utils.DataUtil;
import lombok.Getter;
import lombok.Setter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Getter
public class MemoryDataSource implements DataSource {
    private final Map<String, MovieDataElement> moviesData = new HashMap<>();

    /**
     * Load Movie data
     * @param movies        CsvStream of movies
     * @param movieMetadata CsvStream of movie metadata
     */
    @Override
    public void loadMovieData(Matcher.CsvStream movies, Matcher.CsvStream movieMetadata) {
        Map<String, MovieMetaDataElement> metaDataElementMap = DataUtil.transformMetaDataToMap(movieMetadata);

    }

    /**
     * Closes this stream and releases any system resources associated
     * with it. If the stream is already closed then invoking this
     * method has no effect.
     *
     * <p> As noted in {@link AutoCloseable#close()}, cases where the
     * close may fail require careful attention. It is strongly advised
     * to relinquish the underlying resources and to internally
     * <em>mark</em> the {@code Closeable} as closed, prior to throwing
     * the {@code IOException}.
     *
     * @throws IOException if an I/O error occurs
     */
    @Override
    public void close() throws IOException {
        // clear the data store
        moviesData.clear();
    }
}

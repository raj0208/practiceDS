package com.real.providers;

public interface FeedProvider {
}

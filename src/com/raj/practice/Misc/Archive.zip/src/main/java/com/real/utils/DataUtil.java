package com.real.utils;

import com.real.matcher.Matcher;
import com.real.model.MovieMetaDataElement;

import java.util.Map;

public class DataUtil {

    public static Map<String, MovieMetaDataElement> transformMetaDataToMap(Matcher.CsvStream movieMetadata) {
        return null;
    }
}

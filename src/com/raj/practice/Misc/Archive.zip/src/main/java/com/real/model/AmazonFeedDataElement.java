package com.real.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@Getter
@Builder
@EqualsAndHashCode(callSuper = true)
@ToString
public class AmazonFeedDataElement extends DataElement {
    private String year;
    private String director;
    private String actors;

    /**
     * Returns unique identifier to be used to identify the data element
     *
     * @return unique identifier of the data element
     */
    @Override
    public String getIdentifier() {
        // currently movie title is used as a unique identifier.
        // if required, it can be extended to form a composite key using multiple attributes.
        return this.title.toUpperCase();
    }
}

package com.real.providers;

import com.real.matcher.Matcher;

/**
 * FeedProviderFactory class
 * Used to get provider for a specific database type
 */
public class FeedProviderFactory {
    /**
     * Get FeedProvider based on the database type passed as an argument
     * @param databaseType Datatype of the required FeedProvider
     * @return FeedProvider corresponding to the database type
     */
    public static FeedProvider getProvider(Matcher.DatabaseType databaseType) {
        FeedProvider feedProvider;

        switch(databaseType) {
            case AMAZON_INSTANT:
                feedProvider = new AmazonInstantFeedProvider();
                break;
            case XBOX:
                feedProvider = new XboxFeedProvider();
                break;
            case GOOGLE_PLAY:
            case VUDU:
            default:
                throw new IllegalArgumentException("No FeedProvider defined for " + databaseType);
        }

        return feedProvider;
    }
}

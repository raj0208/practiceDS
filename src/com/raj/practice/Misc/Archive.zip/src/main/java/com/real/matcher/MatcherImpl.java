package com.real.matcher;

import java.util.Collections;
import java.util.List;

import com.real.datasource.DataSource;
import com.real.datasource.DataSourceFactory;
import com.real.datasource.DataSourceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MatcherImpl implements Matcher {

  private static final Logger LOGGER = LoggerFactory.getLogger(MatcherImpl.class);
  private static DataSource moviewDataSource;

  public MatcherImpl(CsvStream movieDb, CsvStream actorAndDirectorDb) {
    LOGGER.info("importing database");
    // Initialize memory
    moviewDataSource = DataSourceFactory.getDataSource(DataSourceType.MEMORY);
    moviewDataSource.loadMovieData(movieDb, actorAndDirectorDb);

    LOGGER.info("database imported");
  }

  @Override
  public List<IdMapping> match(DatabaseType databaseType, CsvStream externalDb) {
    // TODO implement me

    return Collections.emptyList();
  }
}

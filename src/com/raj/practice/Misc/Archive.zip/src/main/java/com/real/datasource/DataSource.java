package com.real.datasource;

import java.io.Closeable;

import static com.real.matcher.Matcher.CsvStream;

public interface DataSource extends Closeable {
    /**
     * Load Movie data
     * @param movies CsvStream of movies
     * @param movieMetadata CsvStream of movie metadata
     */
    void loadMovieData(CsvStream movies, CsvStream movieMetadata);
}

package com.real.providers;

import com.real.matcher.Matcher;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * FeedProviderFactoryTest class
 */
class FeedProviderFactoryTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(FeedProviderFactoryTest.class);

    @Test
    @DisplayName("Test AmazonInstantFeedProvider")
    void test_getProvider_AmazonInstantFeedProvider() {
        FeedProvider feedProvider = FeedProviderFactory.getProvider(Matcher.DatabaseType.AMAZON_INSTANT);
        assertTrue(feedProvider instanceof AmazonInstantFeedProvider);
    }

    @Test
    @DisplayName("Test XboxFeedProvider")
    void test_getProvider_XboxFeedProvider() {
        FeedProvider feedProvider = FeedProviderFactory.getProvider(Matcher.DatabaseType.XBOX);
        assertTrue(feedProvider instanceof XboxFeedProvider);
    }

    @Test
    @DisplayName("Test FeedProvider not defined")
    void test_getProvider_FeedProvider_NotDefined() {
        test_FeedProvider(Matcher.DatabaseType.GOOGLE_PLAY);
        test_FeedProvider(Matcher.DatabaseType.VUDU);
    }

    /**
     * Method to assert test fail for feedprovider not defined
     * @param databaseType DatabaseType to test
     */
    void test_FeedProvider(Matcher.DatabaseType databaseType) {
        FeedProvider feedProvider = null;
        try {
            feedProvider = FeedProviderFactory.getProvider(databaseType);
        } catch (IllegalArgumentException exception) {
            LOGGER.error(exception.toString());
        }finally {
            assertNull(feedProvider);
        }
    }
}
package com.real.datasource;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertNull;

/**
 * FeedProviderFactoryTest class
 */
class DataSourceFactoryTest {
    private static final Logger LOGGER = LoggerFactory.getLogger(DataSourceFactoryTest.class);

    @Test
    @DisplayName("Test MemoryDataSource")
    void test_getDataSource_MemoryDataSource() {
        DataSource dataSource = DataSourceFactory.getDataSource(DataSourceType.MEMORY);
        assertTrue(dataSource instanceof MemoryDataSource);
    }

    @Test
    @DisplayName("Test DataSourceNotDefined")
    void test_getDataSource_DataSourceNotSet()  {
        DataSource dataSource = null;
        try {
            dataSource = DataSourceFactory.getDataSource(DataSourceType.PERSISTANT);
        } catch (IllegalArgumentException exception) {
            LOGGER.error(exception.toString());
        } finally {
            assertNull(dataSource);
        }
    }
}